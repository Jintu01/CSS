First of all thank you for downloading our font.

Please read this carefully before you use or install this font.

- This free version of the font is intended for PERSONAL USE ONLY (NO COMMERCIAL USE ALLOWED)

- If you like to us this font for commercial purpose, you can buy the license from https://www.themewarrior.com/product/overbite-brush-font/

If you need custom license please reach out to us at 
yogi[at]themewarrior.com

You can also support us by sending donation to 
https://paypal.me/andrayogi

Checkout other fonts and other digital products from us on 
https://www.themewarrior.com

Thank you.

Best regards,
ThemeWarrior


=== INDONESIAN VERSION ===

Pertama-tama terima kasih telah mengunduh font kami.

Harap baca ini dengan seksama sebelum Anda menggunakan atau menginstal font ini.

- Font versi gratis ini ditujukan untuk PENGGUNAAN PRIBADI SAJA (TIDAK DIPERBOLEHKAN UNTUK PENGGUNAAN KOMERSIAL)

- Jika Anda ingin menggunakan font ini untuk tujuan komersial, Anda dapat membeli lisensi dari https://www.themewarrior.com/product/overbite-brush-font/

Jika Anda memerlukan lisensi khusus, silakan hubungi kami di
yogi[at]themewarrior.com

Anda juga dapat mendukung kami dengan mengirimkan donasi ke
https://paypal.me/andrayogi

Lihat font lain dan produk digital lainnya dari kami di
https://www.themewarrior.com

Terima kasih.

Salam,
ThemeWarrior